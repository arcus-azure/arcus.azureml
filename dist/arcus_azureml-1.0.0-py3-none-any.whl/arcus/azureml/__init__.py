__all__ = ["version"]
__version__ = '1.0.0' #This will be overwritten in the devops pipelines
