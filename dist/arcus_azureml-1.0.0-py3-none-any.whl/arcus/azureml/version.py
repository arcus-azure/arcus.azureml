import arcus

def output() -> str:
    return arcus.__version__